﻿using Sajat_Projekt.Models;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Sajat_Projekt
{
    public partial class UcGamers : UserControl
    {
        VideoGamesContext context = new VideoGamesContext();
        public UcGamers()
        {
            InitializeComponent();
        }

        private void UcGamers_Load(object sender, EventArgs e)
        {
            GetNames();
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            GetNames();
        }

        private void GetNames()
        {
            gamerBindingSource.DataSource = (from x in context.Gamers where x.Nickname!.Contains(textBox1.Text) select x).ToList();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            var selectedUser = (Gamer)gamerBindingSource.Current;
            var orderToDelete = (from x in context.Gamers
                                 where x.Nickname == selectedUser.Nickname
                                 select x).FirstOrDefault();

            if (orderToDelete != null)
            {
                if (MessageBox.Show($"Biztos törlöd a(z) {orderToDelete.Nickname} játékost?", "Törlés", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
                {
                    context.Gamers.Remove(orderToDelete);
                    context.SaveChanges();
                    GetNames();
                }
            }
            else
            {
                MessageBox.Show("Nincs kiválasztott elem");
            }
        }
    }
}
