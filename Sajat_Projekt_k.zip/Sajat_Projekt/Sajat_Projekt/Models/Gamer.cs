﻿using System;
using System.Collections.Generic;

namespace Sajat_Projekt.Models;

public partial class Gamer
{
    public int GamerId { get; set; }

    public string Nickname { get; set; } = null!;

    public string Email { get; set; } = null!;

    public string? Country { get; set; }

    public DateOnly RegistrationDate { get; set; }

    public virtual ICollection<GameLibrary> GameLibraries { get; set; } = new List<GameLibrary>();
}
