﻿using System;
using System.Collections.Generic;

namespace Sajat_Projekt.Models;

public partial class Platform
{
    public int PlatformId { get; set; }

    public string PlatformName { get; set; } = null!;

    public bool IsActive { get; set; }

    public virtual ICollection<Game> Games { get; set; } = new List<Game>();
}
