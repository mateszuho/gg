﻿using System;
using System.Collections.Generic;

namespace Sajat_Projekt.Models;

public partial class GameLibrary
{
    public int GameLibraryId { get; set; }

    public int GamerFk { get; set; }

    public int GameFk { get; set; }

    public DateOnly OwnedSince { get; set; }

    public int HoursPlayed { get; set; }

    public virtual Game GameFkNavigation { get; set; } = null!;

    public virtual Gamer GamerFkNavigation { get; set; } = null!;
}
