﻿using Sajat_Projekt.Models;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Sajat_Projekt
{
    public partial class UcGameLibrary : UserControl
    {
        VideoGamesContext context = new VideoGamesContext();
        public UcGameLibrary()
        {
            InitializeComponent();
        }

        private void UcGameLibrary_Load(object sender, EventArgs e)
        {
            gameLibraryBindingSource.DataSource = context.GameLibraries.ToList();
            gameBindingSource.DataSource = context.Games.ToList();
            gamerBindingSource.DataSource = context.Gamers.ToList();
        }
    }
}
