﻿namespace Sajat_Projekt
{
    partial class UcGames
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            components = new System.ComponentModel.Container();
            label1 = new Label();
            gameBindingSource = new BindingSource(components);
            listBox1 = new ListBox();
            textBox1 = new TextBox();
            dataGridView1 = new DataGridView();
            gameIdDataGridViewTextBoxColumn = new DataGridViewTextBoxColumn();
            titleDataGridViewTextBoxColumn = new DataGridViewTextBoxColumn();
            releaseYearDataGridViewTextBoxColumn = new DataGridViewTextBoxColumn();
            basePriceDataGridViewTextBoxColumn = new DataGridViewTextBoxColumn();
            genreDataGridViewTextBoxColumn = new DataGridViewTextBoxColumn();
            isMultiplayerDataGridViewCheckBoxColumn = new DataGridViewCheckBoxColumn();
            platformFkDataGridViewTextBoxColumn = new DataGridViewComboBoxColumn();
            platformBindingSource = new BindingSource(components);
            ((System.ComponentModel.ISupportInitialize)gameBindingSource).BeginInit();
            ((System.ComponentModel.ISupportInitialize)dataGridView1).BeginInit();
            ((System.ComponentModel.ISupportInitialize)platformBindingSource).BeginInit();
            SuspendLayout();
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Segoe UI", 14F, FontStyle.Bold);
            label1.Location = new Point(26, 20);
            label1.Name = "label1";
            label1.Size = new Size(81, 25);
            label1.TabIndex = 0;
            label1.Text = "Játékok";
            // 
            // gameBindingSource
            // 
            gameBindingSource.DataSource = typeof(Models.Game);
            // 
            // listBox1
            // 
            listBox1.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left;
            listBox1.DataSource = gameBindingSource;
            listBox1.DisplayMember = "Title";
            listBox1.FormattingEnabled = true;
            listBox1.ItemHeight = 15;
            listBox1.Location = new Point(26, 100);
            listBox1.Name = "listBox1";
            listBox1.Size = new Size(191, 424);
            listBox1.TabIndex = 2;
            // 
            // textBox1
            // 
            textBox1.Location = new Point(26, 64);
            textBox1.Name = "textBox1";
            textBox1.Size = new Size(191, 23);
            textBox1.TabIndex = 3;
            textBox1.TextChanged += textBox1_TextChanged;
            // 
            // dataGridView1
            // 
            dataGridView1.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            dataGridView1.AutoGenerateColumns = false;
            dataGridView1.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridView1.Columns.AddRange(new DataGridViewColumn[] { gameIdDataGridViewTextBoxColumn, titleDataGridViewTextBoxColumn, releaseYearDataGridViewTextBoxColumn, basePriceDataGridViewTextBoxColumn, genreDataGridViewTextBoxColumn, isMultiplayerDataGridViewCheckBoxColumn, platformFkDataGridViewTextBoxColumn });
            dataGridView1.DataSource = gameBindingSource;
            dataGridView1.Location = new Point(244, 43);
            dataGridView1.Name = "dataGridView1";
            dataGridView1.Size = new Size(829, 540);
            dataGridView1.TabIndex = 4;
            // 
            // gameIdDataGridViewTextBoxColumn
            // 
            gameIdDataGridViewTextBoxColumn.DataPropertyName = "GameId";
            gameIdDataGridViewTextBoxColumn.HeaderText = "GameId";
            gameIdDataGridViewTextBoxColumn.Name = "gameIdDataGridViewTextBoxColumn";
            // 
            // titleDataGridViewTextBoxColumn
            // 
            titleDataGridViewTextBoxColumn.DataPropertyName = "Title";
            titleDataGridViewTextBoxColumn.HeaderText = "Title";
            titleDataGridViewTextBoxColumn.Name = "titleDataGridViewTextBoxColumn";
            // 
            // releaseYearDataGridViewTextBoxColumn
            // 
            releaseYearDataGridViewTextBoxColumn.DataPropertyName = "ReleaseYear";
            releaseYearDataGridViewTextBoxColumn.HeaderText = "ReleaseYear";
            releaseYearDataGridViewTextBoxColumn.Name = "releaseYearDataGridViewTextBoxColumn";
            // 
            // basePriceDataGridViewTextBoxColumn
            // 
            basePriceDataGridViewTextBoxColumn.DataPropertyName = "BasePrice";
            basePriceDataGridViewTextBoxColumn.HeaderText = "BasePrice";
            basePriceDataGridViewTextBoxColumn.Name = "basePriceDataGridViewTextBoxColumn";
            // 
            // genreDataGridViewTextBoxColumn
            // 
            genreDataGridViewTextBoxColumn.DataPropertyName = "Genre";
            genreDataGridViewTextBoxColumn.HeaderText = "Genre";
            genreDataGridViewTextBoxColumn.Name = "genreDataGridViewTextBoxColumn";
            // 
            // isMultiplayerDataGridViewCheckBoxColumn
            // 
            isMultiplayerDataGridViewCheckBoxColumn.DataPropertyName = "IsMultiplayer";
            isMultiplayerDataGridViewCheckBoxColumn.HeaderText = "IsMultiplayer";
            isMultiplayerDataGridViewCheckBoxColumn.Name = "isMultiplayerDataGridViewCheckBoxColumn";
            // 
            // platformFkDataGridViewTextBoxColumn
            // 
            platformFkDataGridViewTextBoxColumn.AutoSizeMode = DataGridViewAutoSizeColumnMode.Fill;
            platformFkDataGridViewTextBoxColumn.DataPropertyName = "PlatformFk";
            platformFkDataGridViewTextBoxColumn.DataSource = platformBindingSource;
            platformFkDataGridViewTextBoxColumn.DisplayMember = "PlatformName";
            platformFkDataGridViewTextBoxColumn.HeaderText = "PlatformFk";
            platformFkDataGridViewTextBoxColumn.Name = "platformFkDataGridViewTextBoxColumn";
            platformFkDataGridViewTextBoxColumn.Resizable = DataGridViewTriState.True;
            platformFkDataGridViewTextBoxColumn.SortMode = DataGridViewColumnSortMode.Automatic;
            platformFkDataGridViewTextBoxColumn.ValueMember = "PlatformId";
            // 
            // platformBindingSource
            // 
            platformBindingSource.DataSource = typeof(Models.Platform);
            // 
            // UcGames
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            Controls.Add(dataGridView1);
            Controls.Add(textBox1);
            Controls.Add(listBox1);
            Controls.Add(label1);
            Name = "UcGames";
            Size = new Size(1073, 583);
            Load += UcGames_Load;
            ((System.ComponentModel.ISupportInitialize)gameBindingSource).EndInit();
            ((System.ComponentModel.ISupportInitialize)dataGridView1).EndInit();
            ((System.ComponentModel.ISupportInitialize)platformBindingSource).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label label1;
        private ListBox listBox1;
        private TextBox textBox1;
        private BindingSource gameBindingSource;
        private DataGridView dataGridView1;
        private BindingSource platformBindingSource;
        private DataGridViewTextBoxColumn gameIdDataGridViewTextBoxColumn;
        private DataGridViewTextBoxColumn titleDataGridViewTextBoxColumn;
        private DataGridViewTextBoxColumn releaseYearDataGridViewTextBoxColumn;
        private DataGridViewTextBoxColumn basePriceDataGridViewTextBoxColumn;
        private DataGridViewTextBoxColumn genreDataGridViewTextBoxColumn;
        private DataGridViewCheckBoxColumn isMultiplayerDataGridViewCheckBoxColumn;
        private DataGridViewComboBoxColumn platformFkDataGridViewTextBoxColumn;
    }
}
