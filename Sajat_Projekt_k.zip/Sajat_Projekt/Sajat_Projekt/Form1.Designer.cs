﻿namespace Sajat_Projekt
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            jatekosok = new Button();
            jatekok = new Button();
            statisztikak = new Button();
            exportalas = new Button();
            panel1 = new Panel();
            SuspendLayout();
            // 
            // jatekosok
            // 
            jatekosok.Location = new Point(24, 36);
            jatekosok.Name = "jatekosok";
            jatekosok.Size = new Size(140, 23);
            jatekosok.TabIndex = 0;
            jatekosok.Text = "Játékosok";
            jatekosok.UseVisualStyleBackColor = true;
            jatekosok.Click += jatekosok_Click;
            // 
            // jatekok
            // 
            jatekok.Location = new Point(24, 65);
            jatekok.Name = "jatekok";
            jatekok.Size = new Size(140, 23);
            jatekok.TabIndex = 1;
            jatekok.Text = "Játékok";
            jatekok.UseVisualStyleBackColor = true;
            jatekok.Click += jatekok_Click;
            // 
            // statisztikak
            // 
            statisztikak.Location = new Point(24, 94);
            statisztikak.Name = "statisztikak";
            statisztikak.Size = new Size(140, 23);
            statisztikak.TabIndex = 2;
            statisztikak.Text = "Játékidők / Statisztikák";
            statisztikak.UseVisualStyleBackColor = true;
            statisztikak.Click += statisztikak_Click;
            // 
            // exportalas
            // 
            exportalas.Location = new Point(24, 123);
            exportalas.Name = "exportalas";
            exportalas.Size = new Size(140, 43);
            exportalas.TabIndex = 3;
            exportalas.Text = "Játékosok Exportálás XML-be";
            exportalas.UseVisualStyleBackColor = true;
            exportalas.Click += exportalas_Click;
            // 
            // panel1
            // 
            panel1.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            panel1.Location = new Point(170, -3);
            panel1.Name = "panel1";
            panel1.Size = new Size(845, 539);
            panel1.TabIndex = 4;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(1011, 533);
            Controls.Add(panel1);
            Controls.Add(exportalas);
            Controls.Add(statisztikak);
            Controls.Add(jatekok);
            Controls.Add(jatekosok);
            Name = "Form1";
            Text = "Form1";
            FormClosing += Form1_FormClosing;
            Load += Form1_Load;
            ResumeLayout(false);
        }

        #endregion

        private Button jatekosok;
        private Button jatekok;
        private Button statisztikak;
        private Button exportalas;
        private Panel panel1;
    }
}
