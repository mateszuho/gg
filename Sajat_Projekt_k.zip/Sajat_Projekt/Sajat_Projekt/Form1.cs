using ClosedXML.Excel;
using Sajat_Projekt.Models;

namespace Sajat_Projekt
{
    public partial class Form1 : Form
    {
        VideoGamesContext context = new VideoGamesContext();
        public Form1()
        {
            InitializeComponent();
        }

        private void jatekosok_Click(object sender, EventArgs e)
        {
            panel1.Controls.Clear();
            UcGamers uc = new UcGamers();
            uc.Dock = DockStyle.Fill;
            panel1.Controls.Add(uc);
        }

        private void jatekok_Click(object sender, EventArgs e)
        {
            panel1.Controls.Clear();
            UcGames uc = new UcGames();
            uc.Dock = DockStyle.Fill;
            panel1.Controls.Add(uc);
        }

        private void statisztikak_Click(object sender, EventArgs e)
        {
            panel1.Controls.Clear();
            UcGameLibrary uc = new UcGameLibrary();
            uc.Dock = DockStyle.Fill;
            panel1.Controls.Add(uc);
        }

        private void exportalas_Click(object sender, EventArgs e)
        {
            SaveFileDialog sfd = new SaveFileDialog();
            sfd.Filter = "XLSX f�jl (x.xlsx)|*.xlsx";
            sfd.Title = "V�laszd ki hova szeretn�d menteni";
            sfd.FileName = "jatekosok.xlsx";
            if (sfd.ShowDialog() != DialogResult.OK) return;

            var workbook = new XLWorkbook();
            var worksheet = workbook.Worksheets.Add("Adatb�zis");

            var jatekosok = context.Gamers.ToList();
            worksheet.Cell(1, 1).Value = "GamerId";
            worksheet.Cell(1, 2).Value = "Nickname";
            worksheet.Cell(1, 3).Value = "Email";
            worksheet.Cell(1, 4).Value = "Country";
            worksheet.Cell(1, 5).Value = "RegistrationDate";

            worksheet.Cell(1, 1).Style.Fill.BackgroundColor = XLColor.LightBlue;
            worksheet.Cell(1, 2).Style.Fill.BackgroundColor = XLColor.LightBlue;
            worksheet.Cell(1, 3).Style.Fill.BackgroundColor = XLColor.LightBlue;
            worksheet.Cell(1, 4).Style.Fill.BackgroundColor = XLColor.LightBlue;
            worksheet.Cell(1, 5).Style.Fill.BackgroundColor = XLColor.LightBlue;

            for (int i = 0; i < jatekosok.Count; i++)
            {
                worksheet.Cell(i + 2, 1).Value = jatekosok[i].GamerId;
                worksheet.Cell(i + 2, 2).Value = jatekosok[i].Nickname;
                worksheet.Cell(i + 2, 3).Value = jatekosok[i].Email;
                worksheet.Cell(i + 2, 4).Value = jatekosok[i].Country;
                worksheet.Cell(i + 2, 5).Value = jatekosok[i].RegistrationDate.ToShortDateString();
            }
            workbook.SaveAs(sfd.FileName);
            MessageBox.Show("Sikeres ment�s", "OK", MessageBoxButtons.OK);
        }

        private void Form1_FormClosing(object sender, FormClosingEventArgs e)
        {
            if (MessageBox.Show("Biztosan be akarod z�rni a programot?", "Bez�r�s", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.No)
            {
                e.Cancel = true;
            }
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }
    }
}
