﻿using Sajat_Projekt.Models;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Sajat_Projekt
{
    public partial class UcGames : UserControl
    {
        VideoGamesContext context = new VideoGamesContext();
        public UcGames()
        {
            InitializeComponent();
        }

        private void UcGames_Load(object sender, EventArgs e)
        {
            GetGames();
            platformBindingSource.DataSource = context.Platforms.ToList();
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            GetGames();
        }

        private void GetGames()
        {
            gameBindingSource.DataSource = (from x in context.Games where x.Title!.Contains(textBox1.Text) select x).ToList();
        }
    }
}
