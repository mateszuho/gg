﻿namespace Sajat_Projekt
{
    partial class UcGameLibrary
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            components = new System.ComponentModel.Container();
            dataGridView1 = new DataGridView();
            gameLibraryBindingSource = new BindingSource(components);
            label1 = new Label();
            gameBindingSource = new BindingSource(components);
            gamerBindingSource = new BindingSource(components);
            gameLibraryIdDataGridViewTextBoxColumn = new DataGridViewTextBoxColumn();
            gamerFkDataGridViewTextBoxColumn = new DataGridViewComboBoxColumn();
            gameFkDataGridViewTextBoxColumn = new DataGridViewComboBoxColumn();
            ownedSinceDataGridViewTextBoxColumn = new DataGridViewTextBoxColumn();
            hoursPlayedDataGridViewTextBoxColumn = new DataGridViewTextBoxColumn();
            ((System.ComponentModel.ISupportInitialize)dataGridView1).BeginInit();
            ((System.ComponentModel.ISupportInitialize)gameLibraryBindingSource).BeginInit();
            ((System.ComponentModel.ISupportInitialize)gameBindingSource).BeginInit();
            ((System.ComponentModel.ISupportInitialize)gamerBindingSource).BeginInit();
            SuspendLayout();
            // 
            // dataGridView1
            // 
            dataGridView1.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            dataGridView1.AutoGenerateColumns = false;
            dataGridView1.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridView1.Columns.AddRange(new DataGridViewColumn[] { gameLibraryIdDataGridViewTextBoxColumn, gamerFkDataGridViewTextBoxColumn, gameFkDataGridViewTextBoxColumn, ownedSinceDataGridViewTextBoxColumn, hoursPlayedDataGridViewTextBoxColumn });
            dataGridView1.DataSource = gameLibraryBindingSource;
            dataGridView1.Location = new Point(0, 82);
            dataGridView1.Name = "dataGridView1";
            dataGridView1.Size = new Size(779, 424);
            dataGridView1.TabIndex = 0;
            // 
            // gameLibraryBindingSource
            // 
            gameLibraryBindingSource.DataSource = typeof(Models.GameLibrary);
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Segoe UI", 15F, FontStyle.Bold);
            label1.Location = new Point(14, 20);
            label1.Name = "label1";
            label1.Size = new Size(215, 28);
            label1.TabIndex = 1;
            label1.Text = "Játékosok statisztikái";
            // 
            // gameBindingSource
            // 
            gameBindingSource.DataSource = typeof(Models.Game);
            // 
            // gamerBindingSource
            // 
            gamerBindingSource.DataSource = typeof(Models.Gamer);
            // 
            // gameLibraryIdDataGridViewTextBoxColumn
            // 
            gameLibraryIdDataGridViewTextBoxColumn.DataPropertyName = "GameLibraryId";
            gameLibraryIdDataGridViewTextBoxColumn.HeaderText = "GameLibraryId";
            gameLibraryIdDataGridViewTextBoxColumn.MinimumWidth = 10;
            gameLibraryIdDataGridViewTextBoxColumn.Name = "gameLibraryIdDataGridViewTextBoxColumn";
            // 
            // gamerFkDataGridViewTextBoxColumn
            // 
            gamerFkDataGridViewTextBoxColumn.DataPropertyName = "GamerFk";
            gamerFkDataGridViewTextBoxColumn.DataSource = gamerBindingSource;
            gamerFkDataGridViewTextBoxColumn.DisplayMember = "Nickname";
            gamerFkDataGridViewTextBoxColumn.HeaderText = "GamerFk";
            gamerFkDataGridViewTextBoxColumn.Name = "gamerFkDataGridViewTextBoxColumn";
            gamerFkDataGridViewTextBoxColumn.Resizable = DataGridViewTriState.True;
            gamerFkDataGridViewTextBoxColumn.SortMode = DataGridViewColumnSortMode.Automatic;
            gamerFkDataGridViewTextBoxColumn.ValueMember = "GamerId";
            gamerFkDataGridViewTextBoxColumn.Width = 150;
            // 
            // gameFkDataGridViewTextBoxColumn
            // 
            gameFkDataGridViewTextBoxColumn.DataPropertyName = "GameFk";
            gameFkDataGridViewTextBoxColumn.DataSource = gameBindingSource;
            gameFkDataGridViewTextBoxColumn.DisplayMember = "Title";
            gameFkDataGridViewTextBoxColumn.HeaderText = "GameFk";
            gameFkDataGridViewTextBoxColumn.Name = "gameFkDataGridViewTextBoxColumn";
            gameFkDataGridViewTextBoxColumn.Resizable = DataGridViewTriState.True;
            gameFkDataGridViewTextBoxColumn.SortMode = DataGridViewColumnSortMode.Automatic;
            gameFkDataGridViewTextBoxColumn.ValueMember = "GameId";
            gameFkDataGridViewTextBoxColumn.Width = 150;
            // 
            // ownedSinceDataGridViewTextBoxColumn
            // 
            ownedSinceDataGridViewTextBoxColumn.DataPropertyName = "OwnedSince";
            ownedSinceDataGridViewTextBoxColumn.HeaderText = "OwnedSince";
            ownedSinceDataGridViewTextBoxColumn.Name = "ownedSinceDataGridViewTextBoxColumn";
            ownedSinceDataGridViewTextBoxColumn.Width = 150;
            // 
            // hoursPlayedDataGridViewTextBoxColumn
            // 
            hoursPlayedDataGridViewTextBoxColumn.DataPropertyName = "HoursPlayed";
            hoursPlayedDataGridViewTextBoxColumn.HeaderText = "HoursPlayed";
            hoursPlayedDataGridViewTextBoxColumn.Name = "hoursPlayedDataGridViewTextBoxColumn";
            hoursPlayedDataGridViewTextBoxColumn.Width = 150;
            // 
            // UcGameLibrary
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            Controls.Add(label1);
            Controls.Add(dataGridView1);
            Name = "UcGameLibrary";
            Size = new Size(779, 506);
            Load += UcGameLibrary_Load;
            ((System.ComponentModel.ISupportInitialize)dataGridView1).EndInit();
            ((System.ComponentModel.ISupportInitialize)gameLibraryBindingSource).EndInit();
            ((System.ComponentModel.ISupportInitialize)gameBindingSource).EndInit();
            ((System.ComponentModel.ISupportInitialize)gamerBindingSource).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private DataGridView dataGridView1;
        private BindingSource gameLibraryBindingSource;
        private Label label1;
        private BindingSource gamerBindingSource;
        private BindingSource gameBindingSource;
        private DataGridViewTextBoxColumn gameLibraryIdDataGridViewTextBoxColumn;
        private DataGridViewComboBoxColumn gamerFkDataGridViewTextBoxColumn;
        private DataGridViewComboBoxColumn gameFkDataGridViewTextBoxColumn;
        private DataGridViewTextBoxColumn ownedSinceDataGridViewTextBoxColumn;
        private DataGridViewTextBoxColumn hoursPlayedDataGridViewTextBoxColumn;
    }
}
