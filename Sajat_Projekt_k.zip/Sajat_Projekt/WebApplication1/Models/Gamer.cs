﻿using System;
using System.Collections.Generic;
using System.Text.Json.Serialization;

namespace WebApplication1.Models;

public partial class Gamer
{
    public int GamerId { get; set; }

    public string Nickname { get; set; } = null!;

    public string Email { get; set; } = null!;

    public string? Country { get; set; }

    public DateTime RegistrationDate { get; set; }
    
    [JsonIgnore]
    public virtual ICollection<GameLibrary> GameLibraries { get; set; } = new List<GameLibrary>();
}
