﻿using System;
using System.Collections.Generic;
using Microsoft.EntityFrameworkCore;

namespace WebApplication1.Models;

public partial class VideoGamesContext : DbContext
{
    public VideoGamesContext()
    {
    }

    public VideoGamesContext(DbContextOptions<VideoGamesContext> options)
        : base(options)
    {
    }

    public virtual DbSet<Game> Games { get; set; }

    public virtual DbSet<GameLibrary> GameLibraries { get; set; }

    public virtual DbSet<Gamer> Gamers { get; set; }

    public virtual DbSet<Platform> Platforms { get; set; }

    protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
#warning To protect potentially sensitive information in your connection string, you should move it out of source code. You can avoid scaffolding the connection string by using the Name= syntax to read it from configuration - see https://go.microsoft.com/fwlink/?linkid=2131148. For more guidance on storing connection strings, see http://go.microsoft.com/fwlink/?LinkId=723263.
        => optionsBuilder.UseSqlServer("Server=tcp:mategames.database.windows.net,1433;Initial Catalog=VideoGamesDb;Persist Security Info=False;User ID=mate;Password=Jeff7546;MultipleActiveResultSets=False;Encrypt=True;TrustServerCertificate=False;Connection Timeout=30;");

    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        modelBuilder.Entity<Game>(entity =>
        {
            entity.HasKey(e => e.GameId).HasName("PK__Game__2AB897FD1CB36AD8");

            entity.ToTable("Game");

            entity.Property(e => e.BasePrice).HasColumnType("decimal(10, 2)");
            entity.Property(e => e.Genre).HasMaxLength(40);
            entity.Property(e => e.Title).HasMaxLength(100);

            entity.HasOne(d => d.PlatformFkNavigation).WithMany(p => p.Games)
                .HasForeignKey(d => d.PlatformFk)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_Game_Platform");
        });

        modelBuilder.Entity<GameLibrary>(entity =>
        {
            entity.HasKey(e => e.GameLibraryId).HasName("PK__GameLibr__FC3CBF0B5118ACDA");

            entity.ToTable("GameLibrary");

            entity.Property(e => e.OwnedSince).HasColumnType("date");

            entity.HasOne(d => d.GameFkNavigation).WithMany(p => p.GameLibraries)
                .HasForeignKey(d => d.GameFk)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_GameLibrary_Game");

            entity.HasOne(d => d.GamerFkNavigation).WithMany(p => p.GameLibraries)
                .HasForeignKey(d => d.GamerFk)
                .HasConstraintName("FK_GameLibrary_Gamer");
        });

        modelBuilder.Entity<Gamer>(entity =>
        {
            entity.HasKey(e => e.GamerId).HasName("PK__Gamer__B48340D4F3E46435");

            entity.ToTable("Gamer");

            entity.Property(e => e.Country).HasMaxLength(50);
            entity.Property(e => e.Email).HasMaxLength(100);
            entity.Property(e => e.Nickname).HasMaxLength(40);
            entity.Property(e => e.RegistrationDate).HasColumnType("date");
        });

        modelBuilder.Entity<Platform>(entity =>
        {
            entity.HasKey(e => e.PlatformId).HasName("PK__Platform__F559F6FA487D6037");

            entity.ToTable("Platform");

            entity.Property(e => e.IsActive)
                .IsRequired()
                .HasDefaultValueSql("((1))");
            entity.Property(e => e.PlatformName).HasMaxLength(50);
        });

        OnModelCreatingPartial(modelBuilder);
    }

    partial void OnModelCreatingPartial(ModelBuilder modelBuilder);
}
