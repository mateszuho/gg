﻿using System;
using System.Collections.Generic;

namespace WebApplication1.Models;

public partial class Game
{
    public int GameId { get; set; }

    public string Title { get; set; } = null!;

    public int? ReleaseYear { get; set; }

    public decimal BasePrice { get; set; }

    public string? Genre { get; set; }

    public bool IsMultiplayer { get; set; }

    public int PlatformFk { get; set; }

    public virtual ICollection<GameLibrary> GameLibraries { get; set; } = new List<GameLibrary>();

    public virtual Platform PlatformFkNavigation { get; set; } = null!;
}
