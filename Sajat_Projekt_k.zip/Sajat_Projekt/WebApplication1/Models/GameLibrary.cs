﻿using System;
using System.Collections.Generic;
using System.Text.Json.Serialization;

namespace WebApplication1.Models;

public partial class GameLibrary
{
    public int GameLibraryId { get; set; }

    public int GamerFk { get; set; }

    public int GameFk { get; set; }

    public DateTime OwnedSince { get; set; }

    public int HoursPlayed { get; set; }

    [JsonIgnore]
    public virtual Game GameFkNavigation { get; set; } = null!;
    [JsonIgnore]
    public virtual Gamer GamerFkNavigation { get; set; } = null!;
}
